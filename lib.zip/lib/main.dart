import 'package:flutter/material.dart';
import 'package:gagu_schedule/presentation/home.dart';

void main() {
  runApp(const MyApp());
}
