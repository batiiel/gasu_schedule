part of 'teacher_bloc.dart';

class TeacherState {
  final List<Teacher> teachers;

  TeacherState({this.teachers = const []});
}
