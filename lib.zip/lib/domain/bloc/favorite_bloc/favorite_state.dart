part of 'favorite_bloc.dart';

class FavoriteState {
  final List<Favorite> favorites;

  FavoriteState({
    this.favorites = const [],
  });
}
