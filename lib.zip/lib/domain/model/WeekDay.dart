import 'package:gagu_schedule/domain/model/Rasp.dart';

class WeekDay{
  final String weekDay;
  final String day;
  final List<Rasp> rasp;

  WeekDay({required this.weekDay, required this.day, required this.rasp});

}